import java.io.*;
import java.util.*;

public class TestsGen {
	static int testcount = 0;

	static Random random = new Random(87648341);

	static void write(int n) throws IOException {
		PrintWriter out = new PrintWriter(String.format("%02d", ++testcount));
		System.out.println("Generating test #" + testcount);
		out.println(n);
		out.close();
	}

	public static void main(String[] args) throws IOException {
		while (new File(String.format("%02d.t", testcount + 1)).exists()) {
			testcount++;
		}
		write(2);
		write(3);
		ArrayList<Integer> al = new ArrayList<Integer>();
		for (int i = 4; i <= 100; i++) {
			al.add(i);
		}
		Collections.shuffle(al, random);
		for (int i : al) {
			write(i);
		}
	}

}
